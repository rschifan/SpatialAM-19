pointpats.PointPattern
======================

.. currentmodule:: pointpats

.. automethod:: PointPattern.find_pairs

   