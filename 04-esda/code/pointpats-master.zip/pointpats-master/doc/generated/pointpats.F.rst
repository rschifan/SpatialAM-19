pointpats.F
===========

.. currentmodule:: pointpats

.. autoclass:: F

   
   .. automethod:: __init__

   
   

   
   
   