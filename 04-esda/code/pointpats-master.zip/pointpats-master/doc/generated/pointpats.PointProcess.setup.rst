pointpats.PointProcess
======================

.. currentmodule:: pointpats

.. automethod:: PointProcess.setup

   
   

   
   
   