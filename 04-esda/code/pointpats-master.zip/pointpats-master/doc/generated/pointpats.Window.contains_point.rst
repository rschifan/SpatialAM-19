pointpats.Window
================

.. currentmodule:: pointpats

.. automethod:: Window.contains_point
   