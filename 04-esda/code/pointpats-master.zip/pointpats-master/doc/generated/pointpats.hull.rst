pointpats.hull
==============

.. currentmodule:: pointpats

.. autofunction:: hull