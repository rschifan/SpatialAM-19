pointpats.HexagonM
====================

.. currentmodule:: pointpats

.. automethod:: HexagonM.plot


   
   

   
   
   