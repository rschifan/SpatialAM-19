pointpats.K
===========

.. currentmodule:: pointpats

.. autoclass:: K

   
   .. automethod:: __init__
