pointpats.\_circle
==================

.. currentmodule:: pointpats

.. autofunction:: _circle