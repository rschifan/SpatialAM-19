pointpats.PointProcess
======================

.. currentmodule:: pointpats

.. autoclass:: PointProcess

   
   .. automethod:: __init__
   
   

   
   
   