pointpats.L
===========

.. currentmodule:: pointpats

.. automethod:: L.plot
