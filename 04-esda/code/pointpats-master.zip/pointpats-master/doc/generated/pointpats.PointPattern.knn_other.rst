pointpats.PointPattern
======================

.. currentmodule:: pointpats

.. automethod:: PointPattern.knn_other

   