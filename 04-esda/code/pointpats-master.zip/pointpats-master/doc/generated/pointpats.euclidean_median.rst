pointpats.euclidean\_median
===========================

.. currentmodule:: pointpats

.. autofunction:: euclidean_median