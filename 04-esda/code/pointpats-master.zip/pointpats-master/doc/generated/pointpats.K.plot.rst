pointpats.K
===========

.. currentmodule:: pointpats

.. automethod:: K.plot
