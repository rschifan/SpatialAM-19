pointpats.dtot
==============

.. currentmodule:: pointpats

.. autofunction:: dtot