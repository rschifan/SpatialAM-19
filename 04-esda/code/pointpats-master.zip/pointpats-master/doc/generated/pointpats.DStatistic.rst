pointpats.DStatistic
====================

.. currentmodule:: pointpats

.. autoclass:: DStatistic

   
   .. automethod:: __init__

   
   

   
   
   