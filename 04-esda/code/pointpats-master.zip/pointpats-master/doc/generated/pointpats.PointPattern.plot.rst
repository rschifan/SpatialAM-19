pointpats.PointPattern
======================

.. currentmodule:: pointpats

.. automethod:: PointPattern.plot

   