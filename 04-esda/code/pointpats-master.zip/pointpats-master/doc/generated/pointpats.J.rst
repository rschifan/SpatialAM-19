pointpats.J
===========

.. currentmodule:: pointpats

.. autoclass:: J

   
   .. automethod:: __init__
