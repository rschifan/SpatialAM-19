pointpats.manhattan\_median
===========================

.. currentmodule:: pointpats

.. autofunction:: manhattan_median