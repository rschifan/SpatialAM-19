pointpats.PointPattern
======================

.. currentmodule:: pointpats

.. automethod:: PointPattern.get_window

   