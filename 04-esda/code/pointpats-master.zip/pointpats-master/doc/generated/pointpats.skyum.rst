pointpats.skyum
===============

.. currentmodule:: pointpats

.. autofunction:: skyum