pointpats.Genv
==============

.. currentmodule:: pointpats

.. autoclass:: Genv

   
   .. automethod:: __init__