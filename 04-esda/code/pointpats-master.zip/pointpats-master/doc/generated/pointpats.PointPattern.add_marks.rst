pointpats.PointPattern
======================

.. currentmodule:: pointpats

.. automethod:: PointPattern.add_marks

   