pointpats.PointPattern
======================

.. currentmodule:: pointpats

.. autoclass:: PointPattern

   
   .. automethod:: __init__

   
   