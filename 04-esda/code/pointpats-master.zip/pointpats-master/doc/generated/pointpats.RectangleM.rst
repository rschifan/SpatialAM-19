pointpats.RectangleM
====================

.. currentmodule:: pointpats

.. autoclass:: RectangleM

   
   .. automethod:: __init__

   

   
   
   