pointpats.RectangleM
====================

.. currentmodule:: pointpats

.. automethod:: RectangleM.plot


   
   

   
   
   