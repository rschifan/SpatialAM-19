pointpats.RectangleM
====================

.. currentmodule:: pointpats

.. automethod:: RectangleM.point_location_sta


   
   

   
   
   