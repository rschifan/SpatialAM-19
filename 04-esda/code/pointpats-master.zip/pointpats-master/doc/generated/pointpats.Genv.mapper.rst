pointpats.Genv
==============

.. currentmodule:: pointpats

.. automethod:: Genv.mapper

