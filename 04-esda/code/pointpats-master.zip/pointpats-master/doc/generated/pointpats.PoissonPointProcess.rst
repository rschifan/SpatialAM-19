pointpats.PoissonPointProcess
=============================

.. currentmodule:: pointpats

.. autoclass:: PoissonPointProcess

   
   .. automethod:: __init__

   

   
   
   