pointpats.Fenv
==============

.. currentmodule:: pointpats

.. autoclass:: Fenv

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Fenv.__init__
      ~Fenv.calc
      ~Fenv.mapper
      ~Fenv.plot
   
   

   
   
   