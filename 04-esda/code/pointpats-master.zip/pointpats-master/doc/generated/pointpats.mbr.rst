pointpats.mbr
=============

.. currentmodule:: pointpats

.. autofunction:: mbr