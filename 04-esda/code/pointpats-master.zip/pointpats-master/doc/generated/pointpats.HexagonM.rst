pointpats.HexagonM
==================

.. currentmodule:: pointpats

.. autoclass:: HexagonM

   
   .. automethod:: __init__
   

   
   
   