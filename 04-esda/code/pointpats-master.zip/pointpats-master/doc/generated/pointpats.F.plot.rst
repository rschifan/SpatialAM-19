pointpats.F
============

.. currentmodule:: pointpats

.. automethod:: F.plot
