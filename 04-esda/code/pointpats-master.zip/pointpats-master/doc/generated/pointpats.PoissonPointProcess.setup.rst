pointpats.PoissonPointProcess
====================================

.. currentmodule:: pointpats

.. automethod:: PoissonPointProcess.setup

   
   

   
   
   